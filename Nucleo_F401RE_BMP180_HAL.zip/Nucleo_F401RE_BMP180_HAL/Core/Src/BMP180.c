#include "stm32f4xx_hal.h"
#include "math.h"
#include "main.h"
#include <stdio.h>


// Defines according to the datsheet
short AC1 = 0;
short AC2 = 0;
short AC3 = 0;
unsigned short AC4 = 0;
unsigned short AC5 = 0;
unsigned short AC6 = 0;
short B1 = 0;
short B2 = 0;
short MB = 0;
short MC = 0;
short MD = 0;

/********************/
long UT = 0;
short oss = 0;
long UP = 0;
long X1 = 0;
long X2 = 0;
long X3 = 0;
long B3 = 0;
long B5 = 0;
unsigned long B4 = 0;
long B6 = 0;
unsigned long B7 = 0;

/*******************/
long Press = 0;
long Temp = 0;

#define atmPress 101325 //Pa



#define BMP180_I2C_ADDRESS 0x77  // 7-bit address
#define BMP180_CALIB_DATA_START 0xAA
#define CALIB_DATA_LENGTH 22

extern I2C_HandleTypeDef hi2c1;  // Assuming hi2c1 is your I2C handle

void read_calliberation_data(void)
{
    uint8_t calib_data[CALIB_DATA_LENGTH] = {0};
    uint8_t hal_val = HAL_ERROR;

    //printf("Enter to read data from sensor\r\n");

    while (hal_val == HAL_ERROR || hal_val == HAL_BUSY)
    {
        hal_val = HAL_I2C_Mem_Read(&hi2c1, BMP180_I2C_ADDRESS << 1, BMP180_CALIB_DATA_START, I2C_MEMADD_SIZE_8BIT, calib_data, CALIB_DATA_LENGTH, HAL_MAX_DELAY);

        if (hal_val == HAL_BUSY)
        {
            printf("I2C is busy, resetting I2C peripheral...\r\n");
            __HAL_RCC_I2C1_FORCE_RESET();
            __HAL_RCC_I2C1_RELEASE_RESET();
            MX_I2C1_Init();  // Re-initialize the I2C peripheral
        }
        else if (hal_val != HAL_OK)
        {
            printf("I2C read error, hal_val = %d\r\n", hal_val);
        }
    }

    if (hal_val == HAL_OK)
    {
       // printf("Calibration data read successfully\r\n");

        AC1 = ((calib_data[0] << 8) | calib_data[1]);
        AC2 = ((calib_data[2] << 8) | calib_data[3]);
        AC3 = ((calib_data[4] << 8) | calib_data[5]);
        AC4 = ((calib_data[6] << 8) | calib_data[7]);
        AC5 = ((calib_data[8] << 8) | calib_data[9]);
        AC6 = ((calib_data[10] << 8) | calib_data[11]);
        B1 = ((calib_data[12] << 8) | calib_data[13]);
        B2 = ((calib_data[14] << 8) | calib_data[15]);
        MB = ((calib_data[16] << 8) | calib_data[17]);
        MC = ((calib_data[18] << 8) | calib_data[19]);
        MD = ((calib_data[20] << 8) | calib_data[21]);

//        printf("AC1 = %d\n", AC1);
//               printf("AC2 = %d\n", AC2);
//               printf("AC3 = %d\n", AC3);
//               printf("AC4 = %u\n", AC4);
//               printf("AC5 = %u\n", AC5);
//               printf("AC6 = %u\n", AC6);
//               printf("B1 = %d\n", B1);
//               printf("B2 = %d\n", B2);
//               printf("MB = %d\n", MB);
//               printf("MC = %d\n", MC);
//               printf("MD = %d\n", MD);
    }
    else
    {
        printf("Failed to read calibration data from BMP180\r\n");
    }
}


// Get uncompensated Temp
uint16_t Get_UTemp (void)
{
	uint8_t datatowrite = 0x2E;
	uint8_t Temp_RAW[2] = {0};
	HAL_I2C_Mem_Write(&hi2c1, BMP180_I2C_ADDRESS << 1, 0xF4, 1, &datatowrite, 1, 1000);
	HAL_Delay (5);  // wait 4.5 ms
	HAL_I2C_Mem_Read(&hi2c1, BMP180_I2C_ADDRESS << 1, 0xF6, 1, Temp_RAW, 2, 1000);
	return ((Temp_RAW[0]<<8) + Temp_RAW[1]);
}

float BMP180_GetTemp (void)
{
	UT = Get_UTemp();
	X1 = ((UT-AC6) * (AC5/(pow(2,15))));
	X2 = ((MC*(pow(2,11))) / (X1+MD));
	B5 = X1+X2;
	Temp = (B5+8)/(pow(2,4));
	return (Temp/10.0);
}

// Get uncompensated Pressure
uint32_t Get_UPress (int oss)   // oversampling setting 0,1,2,3
{
	uint8_t datatowrite = 0x34+(oss<<6);
	uint8_t Press_RAW[3] = {0};
	HAL_I2C_Mem_Write(&hi2c1, BMP180_I2C_ADDRESS << 1, 0xF4, 1, &datatowrite, 1, 1000);
	switch (oss)
	{
		case (0):
			HAL_Delay (5);
			break;
		case (1):
			HAL_Delay (8);
			break;
		case (2):
			HAL_Delay (14);
			break;
		case (3):
			HAL_Delay (26);
			break;
	}
	HAL_I2C_Mem_Read(&hi2c1, BMP180_I2C_ADDRESS << 1, 0xF6, 1, Press_RAW, 3, 1000);
	return (((Press_RAW[0]<<16)+(Press_RAW[1]<<8)+Press_RAW[2]) >> (8-oss));
}


float BMP180_GetPress (int oss)
{
	UP = Get_UPress(oss);
	X1 = ((UT-AC6) * (AC5/(pow(2,15))));
	X2 = ((MC*(pow(2,11))) / (X1+MD));
	B5 = X1+X2;
	B6 = B5-4000;
	X1 = (B2 * (B6*B6/(pow(2,12))))/(pow(2,11));
	X2 = AC2*B6/(pow(2,11));
	X3 = X1+X2;
	B3 = (((AC1*4+X3)<<oss)+2)/4;
	X1 = AC3*B6/pow(2,13);
	X2 = (B1 * (B6*B6/(pow(2,12))))/(pow(2,16));
	X3 = ((X1+X2)+2)/pow(2,2);
	B4 = AC4*(unsigned long)(X3+32768)/(pow(2,15));
	B7 = ((unsigned long)UP-B3)*(50000>>oss);
	if (B7<0x80000000) Press = (B7*2)/B4;
	else Press = (B7/B4)*2;
	X1 = (Press/(pow(2,8)))*(Press/(pow(2,8)));
	X1 = (X1*3038)/(pow(2,16));
	X2 = (-7357*Press)/(pow(2,16));
	Press = Press + (X1+X2+3791)/(pow(2,4));

	return Press;
}


float BMP180_GetAlt (int oss)
{
	BMP180_GetPress (oss);
	return 44330*(1-(pow((Press/(float)atmPress), 0.19029495718)));
}

void BMP180_Start (void)
{
	read_calliberation_data();
}
void MX_I2C1_Init(void)
{
    hi2c1.Instance = I2C1;
    hi2c1.Init.ClockSpeed = 100000;
    hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
    hi2c1.Init.OwnAddress1 = 0;
    hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
    hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
    hi2c1.Init.OwnAddress2 = 0;
    hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
    hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
    if (HAL_I2C_Init(&hi2c1) != HAL_OK)
    {
        // Initialization Error
        while (1);
    }
}
